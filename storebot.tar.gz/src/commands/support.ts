import { MyContext } from "../types";
import { ObjectId } from "mongodb";
import { t } from "../languages";
import logger from "../helpers/logger";

const log = logger.child({ tag: "SupportCmd" });

const WHATSAPP_URL = process.env.SUPPORT_WHATSAPP_URL || "https://wa.me/213776863561";
const TELEGRAM_URL = process.env.SUPPORT_TELEGRAM_URL || "https://t.me/Jeogooussama";

export const handleSupportView = async (ctx: MyContext, sellerId?: ObjectId) => {
  try {
    const message =
      `${t().support.title}\n\n` +
      `WhatsApp: ${WHATSAPP_URL}\n` +
      `Telegram: ${TELEGRAM_URL}`;

    await ctx.reply(message);
  } catch (error) {
    log.error({ err: error }, "Error in handleSupportView");
    await ctx.reply(t().support.errorLoading);
  }
};
